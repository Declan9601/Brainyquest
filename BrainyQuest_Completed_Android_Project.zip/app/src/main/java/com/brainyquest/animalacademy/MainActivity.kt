package com.brainyquest.animalacademy

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View

class MainActivity : Activity() {
    private lateinit var game: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
             View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        game = WebView(this)
        game.settings.javaScriptEnabled = true
        game.settings.domStorageEnabled = true
        game.settings.mediaPlaybackRequiresUserGesture = true
        game.webChromeClient = WebChromeClient()
        game.webViewClient = WebViewClient()
        game.loadUrl("file:///android_asset/index.html")
        setContentView(game)
    }
    override fun onBackPressed() {
        if (game.canGoBack()) game.goBack() else super.onBackPressed()
    }
}
