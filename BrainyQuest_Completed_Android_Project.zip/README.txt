Brainy Quest: Animal Academy — Android Studio project
This is Android app source code, not a precompiled APK.

To build an installable APK:
1. Install Android Studio on a computer.
2. Open this BrainyQuest folder as a project.
3. Let Android Studio sync Gradle and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is typically at app/build/outputs/apk/debug/app-debug.apk.
6. Transfer that APK to your Android phone and open it. Android may ask you to allow installs from that source.

The game runs from the bundled local HTML asset and its music is generated in the game.
